# Tasks

- [x] Insurance start date: auto-fill today's date, opens calendar picker on click (QuoteDetails.tsx)
- [x] Hide Lovable badge widget globally (src/styles.css)
