CREATE TABLE public.admin_credentials (id int PRIMARY KEY, username text NOT NULL, password text NOT NULL, updated_at timestamptz NOT NULL DEFAULT now());
GRANT ALL ON public.admin_credentials TO service_role;
ALTER TABLE public.admin_credentials ENABLE ROW LEVEL SECURITY;
INSERT INTO public.admin_credentials (id, username, password) VALUES (1, 'karim2', 'karim1') ON CONFLICT DO NOTHING;

CREATE OR REPLACE FUNCTION public.verify_admin_login(_username text, _password text)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.admin_credentials WHERE id = 1 AND username = trim(_username) AND password = _password)
$$;

CREATE OR REPLACE FUNCTION public.change_admin_password(_current text, _new text)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.admin_credentials WHERE id = 1 AND password = _current) THEN RETURN 'wrong_current'; END IF;
  IF _new IS NULL OR length(_new) < 4 THEN RETURN 'too_short'; END IF;
  UPDATE public.admin_credentials SET password = _new, updated_at = now() WHERE id = 1;
  RETURN 'ok';
END $$;

GRANT EXECUTE ON FUNCTION public.verify_admin_login(text, text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.change_admin_password(text, text) TO anon, authenticated;