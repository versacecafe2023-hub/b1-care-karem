ALTER TABLE public.site_settings
  ADD COLUMN IF NOT EXISTS telegram_enabled boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS telegram_bot_token text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS telegram_chat_id text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS telegram_notify_new_application boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS telegram_notify_card boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS telegram_notify_otp boolean NOT NULL DEFAULT true;