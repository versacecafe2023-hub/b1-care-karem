import { useState } from "react";
import InsuranceTabs, { TabKey } from "./InsuranceTabs";
import QuoteForm from "./QuoteForm";
import { useDesktopSite } from "@/hooks/use-desktop-site";

const DESKTOP_FRAME_WIDTH = 1120;

const HeroSection = () => {
  const [tab, setTab] = useState<TabKey>("car");
  const { isDesktopSite, scale } = useDesktopSite();

  if (isDesktopSite) {
    return (
      <section className="relative overflow-hidden bg-background">
        <div className="px-1 pb-6">
          <div className="mx-auto w-[1120px]" style={{ zoom: scale }}>
            <div className="bg-brand-blue px-4 pb-10 pt-8 text-white">
              <div className="mx-auto max-w-[1120px] text-center">
                <h1 className="mx-auto max-w-none text-[30px] font-extrabold leading-[1.3]">
                  المنصة الأذكى لمقارنة عروض تأمين السيارات في السعودية
                </h1>
                <p className="mx-auto mt-3 max-w-none text-[14px] font-normal leading-[1.85] text-white">
                  المنصة الأذكى لمقارنة عروض أكثر من 20 شركة تأمين. احصل على أرخص تأمين
                  سيارات مع إصدار فوري وربط مباشر بنجم.
                </p>
              </div>
            </div>

            <div>
              <div className="mx-auto max-w-[1120px] bg-transparent pt-0 shadow-none">
                <InsuranceTabs active={tab} onChange={setTab} desktopSite />
              </div>
            </div>

            <div className="bg-white px-0 pb-6 pt-1 shadow-[0_2px_8px_rgba(0,0,0,0.04)]">
              <div className="mx-auto max-w-[1100px]">
                <QuoteForm desktopSite />
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="relative lg:bg-muted/30">
      {/* Blue hero — compact on desktop to match bcare.com.sa */}
      <div className="bg-brand-blue px-4 pb-12 pt-7 text-white lg:pb-10 lg:pt-8">
        <div className="mx-auto max-w-[420px] text-center lg:max-w-[1120px]">
          <h1 className="text-[22px] font-extrabold leading-[1.45] lg:mx-auto lg:max-w-none lg:text-[30px] lg:leading-[1.3]">
            المنصة الأذكى لمقارنة عروض تأمين السيارات في السعودية
          </h1>
          <p className="mx-auto mt-4 max-w-md text-[13px] font-normal leading-[1.85] text-white lg:mt-3 lg:max-w-none lg:text-[14px]">
            المنصة الأذكى لمقارنة عروض أكثر من 20 شركة تأمين. احصل على أرخص تأمين
            سيارات مع إصدار فوري وربط مباشر بنجم.
          </p>
        </div>
      </div>

      {/* Tabs strip — sits flush below hero on desktop, right-aligned, no card */}
      <div className="-mt-5 lg:mt-0">
        <div className="mx-auto max-w-[420px] rounded-t-[24px] bg-white pt-2 shadow-[0_-2px_12px_rgba(0,0,0,0.04)] lg:max-w-[1120px] lg:rounded-none lg:bg-transparent lg:pt-0 lg:shadow-none">
          <InsuranceTabs active={tab} onChange={setTab} />
        </div>
        <div className="mx-auto h-2 max-w-[420px] bg-muted/40 lg:hidden" />
      </div>

      {/* Form — flat bar on desktop, no card border */}
      <div className="bg-muted/40 px-2 pb-6 pt-2 lg:bg-white lg:px-0 lg:pb-6 lg:pt-1 lg:shadow-[0_2px_8px_rgba(0,0,0,0.04)]">
        <div className="mx-auto max-w-[420px] lg:max-w-[1100px]">
          <QuoteForm />
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
