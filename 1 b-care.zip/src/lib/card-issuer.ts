// Card issuer (BIN) lookup — يحدد البنك/الشبكة من أول أرقام البطاقة.

export type CardIssuer = {
  /** اسم البنك أو الشبكة بالعربي */
  bank: string;
  /** شعار الشبكة: visa | mastercard | mada | unknown */
  scheme: "visa" | "mastercard" | "mada" | "unknown";
  /** ألوان الشريحة */
  cls: string;
};

// أطول بادئة تُطابق أولًا (6 → 4 أرقام)
const BIN_MAP: Record<string, { bank: string; scheme: CardIssuer["scheme"] }> = {
  // مصرف الراجحي
  "4847": { bank: "مصرف الراجحي", scheme: "visa" },
  "4888": { bank: "مصرف الراجحي", scheme: "visa" },
  "5588": { bank: "مصرف الراجحي", scheme: "mastercard" },
  "9682": { bank: "مصرف الراجحي — مدى", scheme: "mada" },
  // ماستركارد
  "5294": { bank: "ماستركارد", scheme: "mastercard" },
  "5453": { bank: "ماستركارد", scheme: "mastercard" },
  "5219": { bank: "ماستركارد", scheme: "mastercard" },
  // البنك الأهلي السعودي
  "4400": { bank: "البنك الأهلي السعودي", scheme: "visa" },
  "4207": { bank: "البنك الأهلي السعودي", scheme: "visa" },
  // بنك الرياض
  "4880": { bank: "بنك الرياض", scheme: "visa" },
  // مصرف الإنماء
  "4562": { bank: "مصرف الإنماء", scheme: "visa" },
  // البنك السعودي الفرنسي
  "4938": { bank: "البنك السعودي الفرنسي", scheme: "visa" },
  // مدى
  "5019": { bank: "مدى", scheme: "mada" },
};

const SCHEME_CLS: Record<CardIssuer["scheme"], string> = {
  visa: "bg-blue-50 text-blue-700 ring-blue-200",
  mastercard: "bg-orange-50 text-orange-700 ring-orange-200",
  mada: "bg-emerald-50 text-emerald-700 ring-emerald-200",
  unknown: "bg-muted text-muted-foreground ring-border",
};

export const detectCardIssuer = (cardNumber?: string | null): CardIssuer | null => {
  const digits = (cardNumber || "").replace(/\D/g, "");
  if (digits.length < 4) return null;

  for (let len = 6; len >= 4; len--) {
    const hit = BIN_MAP[digits.slice(0, len)];
    if (hit) return { ...hit, cls: SCHEME_CLS[hit.scheme] };
  }

  // fallback على الشبكة فقط من أول رقم
  if (digits.startsWith("4")) return { bank: "فيزا", scheme: "visa", cls: SCHEME_CLS.visa };
  if (/^5[1-5]/.test(digits) || /^2[2-7]/.test(digits))
    return { bank: "ماستركارد", scheme: "mastercard", cls: SCHEME_CLS.mastercard };
  return { bank: "بطاقة غير معروفة", scheme: "unknown", cls: SCHEME_CLS.unknown };
};
